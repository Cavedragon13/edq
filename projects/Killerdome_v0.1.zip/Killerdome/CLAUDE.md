# CLAUDE.md — Standing Orders for Killerdome, Inc.

You are the implementation agent for *Killerdome, Inc.*, a satirical management simulation.
These rules are binding. When they conflict with convenience, the rules win.

## Read Order (every session)

1. This file.
2. `README.md` — high concept and design rules.
3. `docs/ROADMAP.md` — find the current phase (first phase not marked COMPLETE in `docs/CHANGELOG.md`).
4. Only the docs relevant to the current phase (each phase lists them).

## Workflow Rules

- Implement **one roadmap phase per session** unless the operator explicitly says otherwise.
- A phase is done only when every item in its **Acceptance Criteria** passes.
- At the end of a phase: run all checks, update `docs/CHANGELOG.md` with a dated entry, **stop and await review**. Do not begin the next phase.
- Never mark a phase COMPLETE if any acceptance criterion is unverified.
- If a design doc is ambiguous, make the smallest reasonable choice, implement it, and record the decision in `docs/CHANGELOG.md` under "Decisions." Do not silently invent new systems.
- Never delete or rewrite design docs. Append clarifications to `docs/CHANGELOG.md` instead.

## Technical Constraints

- **Stack:** TypeScript (strict mode) + Vite. Vanilla DOM or minimal rendering helpers. No frameworks, no runtime dependencies. Dev dependencies limited to: `vite`, `typescript`, `vitest`.
- **Target:** static single-page app. `npm run build` must produce a self-contained `dist/` deployable from any static host or opened locally.
- **Saves:** `localStorage`, JSON, versioned with a `saveVersion` field and a migration function per version bump.
- **Determinism:** all randomness flows through one seeded PRNG module (`src/engine/rng.ts`, mulberry32 or equivalent). No bare `Math.random()` anywhere. Game state + seed must reproduce a run.
- **Data-driven:** content (lenders, events, characters, incidents, news strings, exec-suite rungs) lives in typed data modules under `src/data/`, never inline in logic.
- **Simulation core is UI-free:** `src/engine/` must not import from `src/ui/`. The engine must be runnable headless in tests.
- **Security/hygiene:** no `eval`, no `innerHTML` with interpolated strings (use `textContent`/DOM building or a tiny sanitizer), no external network calls, no analytics, CSP-compatible output.
- **Tests:** Vitest. Every engine subsystem gets unit tests; every phase's acceptance criteria that can be automated must be a test.
- **Checks before any commit/stop:** `npx tsc --noEmit`, `npx vitest run`, `npm run build` all pass.

## Tone Rules (binding on every string in the game)

These implement README Design Rules #3 and #4. See `docs/STYLEGUIDE.md`.

1. Every player-facing string must pass the test: *"Would an actual corporate communications professional write this?"*
2. The game never winks. No dark jokes, no ironic achievement names, no skulls, no blood-red UI. The interface looks like enterprise software.
3. Violence is only ever referred to in euphemism appropriate to the speaker (legal, PR, actuarial, broadcast). The euphemism escalates over eras per `docs/STYLEGUIDE.md`.
4. The player is never told the game is satire. Discovery is the player's job.

## Scope Discipline

- The management simulation must be fun as a management simulation (README Project Goals). If a satirical flourish costs loop clarity, cut the flourish.
- No combat gameplay. Fights resolve as simulation events with business consequences.
- Do not add systems not specified in `docs/SYSTEMS.md` without operator approval.
