# ENDINGS.md — Killerdome, Inc.

Version 0.1. Governing rule: **every ending is delivered as a corporate document.** No game-over screens, no editorializing, no music sting. The ending format is Design Rule #3 enforced structurally.

| # | Ending | Trigger | Closing document |
|---|---|---|---|
| 1 | **Bankruptcy** | DEBT fail with institutional lenders | Chapter 7 asset liquidation report, itemized |
| 2 | **The Ernie Ending** | Default on Tier-1 debt in Era 1–2 | Terse news clipping announcing "a change in ownership" + a warm memorial paragraph in the company newsletter |
| 3 | **Legislative Ban** | Hostile bill passes (sustained HEAT + lost lobbying war) | Asset sale documentation; a final clipping notes the quarry site will become a water park |
| 4 | **Hostile Takeover** | Public company, share price + activist investor event | Press release welcoming the player as "Founder Emeritus." Losing by winning too well |
| 5 | **The Cascade** | Strike breaks flagship TV contract → covenant defaults chain | Sequence of increasingly short internal memos, ending in one line from Meridian |
| 6 | **Institutionalization (VICTORY)** | See below | Harvard Business School case study written about the player |

## Ending 6 — Institutionalization

The ultimate victory completes the satire arc: the player has normalized the unthinkable so completely that the world considers it as American as football.

Milestone ladder (all must be achieved, any order):

- The **Combat Entertainment Standards Act** passes — federal regulation your own legal team helped draft. Sounds like defeat; is legitimacy, plus compliance costs that crush every smaller rival.
- A Killerdome fighter appears on a **cereal box** (licensing milestone).
- A **sitting president attends** a match (HEAT low + prestige high in an election year).
- **Olympic exhibition event** (international expansion + federation lobbying).
- **The Island** completed (SYSTEMS.md §10) at healthy gauges.

Closing sequence: induction into a business hall of fame, then the case study — which notes, in passing, that the Strategic Leadership Retreat was of course tax deductible.

## Notes for implementation

- Endings are data-driven documents (`src/data/endings.ts`) assembled from the player's actual history: real names, real dates, real figures from the run. The liquidation report itemizes *your* assets; the case study cites *your* milestones.
- Ending 3 is arguably the morally good ending. The game must present it, straight-faced, as failure — because you are the CEO and the game never breaks character.
- Milestone progress for Ending 6 is visible mid-game as an ordinary corporate OKR dashboard.
