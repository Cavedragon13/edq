# SYSTEMS.md — Killerdome, Inc.

Version 0.1 — pre-production. All numbers are placeholder tunables and live in `src/data/balance.ts`.

---

## 1. Time & Tick

- Base unit: **1 week**. The player advances time; the simulation resolves weekly.
- 52 weeks = 1 year. Characters age, contracts expire, elections occur on the calendar.
- **Eras** gate content and language (see STYLEGUIDE.md):
  - Era 1 — *Roadside* (years 1–3): illegal/gray-market, quarry venue, Ernie-tier finance.
  - Era 2 — *Regional* (years 3–8): sanctioned in select states, TV deals, institutional lenders.
  - Era 3 — *National* (years 8–15): public company option, federal politics, league rivals.
  - Era 4 — *Institutional* (years 15+): global capital, endgame tracks, island unlock.
- Era transitions are triggered by milestones (revenue, legality map, media reach), not by date alone.

---

## 2. The Four Gauges

The strategic layer is four visible pressure gauges (0–100). Fail states trigger at sustained extremes; the interesting decisions come from the coupling matrix (§3).

| Gauge | Meaning | Raised by | Lowered by | Fail state at sustained 100 |
|---|---|---|---|---|
| **DEBT** | Leverage vs. capacity to service it | Loans, construction, bidding wars, revenue shortfalls | Profits, refinancing, asset sales | Bankruptcy / lender endgame (§5) |
| **HEAT** | Political & regulatory pressure | Incidents, exposés, opposition figures, leaks | Lobbying, PACs, foundations, favorable studies, jobs created | Legislative ban (ENDINGS.md §3) |
| **RISK** | Actuarial risk score | Incidents, unsafe formats, aging medical staff, deferred maintenance | Safety spend, medical staff, rule changes, equipment | Insurance collapse → cannot legally hold events (§6) |
| **LABOR** | Fighter/staff discontent | Low pay, injuries, denied benefits, botched negotiations, leaked buyouts | Concessions, benefits, star treatment, association deals | Strike during flagship event → contract cascade (§7) |

- Gauges display as clean corporate dashboards ("Regulatory Affairs Index", "Enterprise Risk Score", "Workforce Engagement"). The player-facing names are euphemisms; the tooltip math is honest.
- Fail states require **sustained** extremes (e.g., HEAT ≥ 90 for 26 consecutive weeks while a hostile bill is live), so the player always sees it coming and can trade against it.

---

## 3. Coupling Matrix

No lever moves one gauge. Canonical couplings (v0.1):

| Action | DEBT | HEAT | RISK | LABOR |
|---|---|---|---|---|
| Cut safety budget | ▼ | ▲ (if incident) | ▲▲ | ▲ |
| Take Ernie-tier loan | ▼ cash crisis, ▲ gauge | ▲ (if exposed) | ▲ (collections events) | — |
| Heel-turn buyout (§7) | ▲ (payout) | ▲▲ delayed (leak) | — | ▼▼ now, ▲▲ if leaked |
| Lobbying spend | ▲ | ▼▼ | — | — |
| Raise fighter pay | ▲ | ▼ (goodwill) | — | ▼▼ |
| Book unsafe marquee format | ▼▼ (revenue) | ▲▲ | ▲▲ | ▲ |
| Charitable foundation | ▲ | ▼ | — | ▼ |
| Go public (Era 3) | ▼▼▼ | ▲ | — | ▲ (cost pressure) |

Implementation: each action declares a typed `GaugeDelta[]`, some immediate, some scheduled (delayed bombs), some conditional on later events (leak checks).

---

## 4. Core Economic Loop

Weekly resolution order:

1. **Fixed costs**: payroll, facility upkeep, insurance premium (function of RISK), debt service (function of DEBT and lender tier).
2. **Events**: any scheduled show resolves — attendance model × ticket price + concessions + parking + PPV/TV revenue share − event costs − incident rolls.
3. **Incidents**: RNG weighted by RISK, card composition, and format. Outcomes range from "minor injury" to "talent attrition event." Incidents feed HEAT, RISK, LABOR, and the news feed.
4. **Random events**: drawn from `docs/EVENTS.md` pools, era-gated.
5. **Gauge decay/drift**: gauges drift toward baselines set by standing policies (lobbying retainer, safety program level, benefits package).

Attendance model v0.1: `base_draw(venue, market) × card_quality × hype × weather × price_elasticity`. Keep it legible; the player should be able to reason about why a show sold.

---

## 5. Capital & Lenders

Three tiers, unlocked by era. Loans remain relevant late via §8 money sinks.

### Tier 1 — Ernie & Associates (Era 1)
- Instant cash, no paperwork, no collateral. Rates are absurd (weekly vig).
- Missed payments trigger **collections events**: sabotaged equipment, a headliner's mysteriously broken hand the week of the show, a "small fire."
- Default endgame: terse ownership-change news clipping + memorial newsletter paragraph (ENDINGS.md §2).
- Satire note: never called loan sharks. UI label: *"Community Lending Partner."*

### Tier 2 — Meridian Capital Solutions (Era 2–3)
- Larger sums, covenants (minimum cash, maximum RISK), board seats at higher amounts.
- Board seats inject **directives**: "our analysis suggests audiences respond to higher-stakes formats." Refusing costs refinancing access; complying moves gauges.

### Tier 3 — Sovereign / Global Capital (Era 3–4)
- Effectively limitless. Strings are content strings: broadcast topic restrictions, mandatory exhibition events, image obligations. HEAT interactions if press notices.

Refinancing up-tier is a core midgame move (retire Ernie with Meridian money) and should feel like escaping — then rhyming.

---

## 6. Insurance & the Captive

- Premiums = `base × f(RISK)`, superlinear above RISK 60.
- Carriers have patience: enough incidents and your carrier non-renews; each subsequent carrier is pricier and twitchier.
- **Zero carriers ⇒ cannot legally hold sanctioned events** (Era 2+). Revenue suffocates; this is the quiet actuarial fail state.
- **Era 3 unlock — Captive Insurance Subsidiary (Delaware):** self-insure. Premiums vanish; instead every incident pays out of your own treasury. Every safety decision becomes a direct wager. Converts a boring fail state into a casino the player owns. Requires capitalization (big DEBT sink) and a compliance officer hire.

---

## 7. Talent, Contracts & Labor

- Roster of fighters with stats (draw power, durability, age curve, temperament), plus staff (medical, legal, PR, operations) as hires that set policy baselines.
- **Contract negotiation minigame** (Football Manager-style): offers/counteroffers over pay, bout minimums, death benefits, medical coverage, image rights. Company's standing dodge: *independent contractor* classification — cheap, but every use raises LABOR and stockpiles ammunition for the association.
- **The Association** (midgame faction): forms when LABOR crosses threshold with a charismatic ringleader present. Sentiment managed via concessions, star treatment, recognition/non-recognition.
- **Ringleader resolutions:**
  - *Quiet buyout*: pay them out, they retire. LABOR ▼, small delayed leak risk, martyr risk if they later go public.
  - **Heel turn**: the ringleader signs an exclusive headline deal and denounces the association **on your own broadcast**. LABOR ▼▼ immediately, hype ▲▲ (it's a great show), but plants a scheduled **leak bomb**: if "internal memo reveals payout" fires (RNG weighted by staff loyalty and press scrutiny), LABOR ▲▲▲, HEAT ▲▲, and the association radicalizes with martyrdom multiplier.
  - *Recognition*: negotiate with the association as an entity. Costs money forever, permanently lowers LABOR volatility. The boring, stable option.
- **Strike**: sustained LABOR 100 during a flagship event window breaks the TV contract; contract cascade is the fail sequence (ENDINGS.md §5 adjacency).

---

## 8. Expansion & Money Sinks (keeps debt alive late)

Time-limited windows, era-gated, all debt-hungry:

- **Distressed league acquisitions** ("the Reno league is insolvent — 8 weeks before a competitor moves").
- **Stadium construction**: 18 months of burn before revenue.
- **Free-agent bidding wars** against rival leagues.
- **Marquee PPV gamble**: book the biggest card in history; triple return or crater, with RISK/HEAT exposure.
- **Broadcast rights auctions**; **international market entry** (new legality maps, new HEAT ecosystems).
- **Going public** (Era 3): massive capital, quarterly earnings pressure becomes a standing directive engine, hostile-takeover exposure (ENDINGS.md §4).

---

## 9. Politics & HEAT Ecosystem

HEAT is a gauge fed by an ecosystem of named actors, not an abstract meter:

- **The Senator**: builds a career opposing you; escalates from statements to hearings to a bill. Bills are the legislative fail clock.
- **The Widow**: emerges from a fatality incident; becomes a movement with its own momentum.
- **The Documentary Crew**: access request — grant (humanizing but risky) or deny (suspicious). Either way, a delayed content bomb.
- Counter-tools (all real corporate tools): lobbying retainers, PAC donations, charitable foundation, "independent" safety study, hiring the Senator's former chief of staff, jobs-created press events.
- Legality is a **state-by-state map** in Eras 1–2, federal in Eras 3–4. Regulation can be *won*: the Combat Entertainment Standards Act (ENDINGS.md §6) is a victory condition dressed as oversight.

---

## 10. Exec Suite Ladder (personal-greed track)

Parallel vanity track competing for the same treasury. Each rung: pure spend, small hype/prestige bonuses, quiet indictment.

1. Better office → 2. Company car → 3. Jet → 4. Skybox → 5. Penthouse → 6. **The Island**.

**The Island (Era 4, terminal sink):** purchase a private island ("Strategic Leadership Retreat" on the deed) and enter a compressed builder minigame — helipad, marina, wellness pavilion, conference center for the people who used to regulate you, and a **private arena** for invitation-only exhibition matches: the sport returned to its illegal roots as the world's most exclusive luxury product. Tax deductible. Completing the island at high company health feeds the Institutionalization ending (ENDINGS.md §6).

---

## 11. News Feed (satire delivery system)

- Every incident, decision, and era transition emits news items into a persistent, scrollable history.
- Clippings drift in tone across eras (STYLEGUIDE.md euphemism ladder). The fighter recruited in year 2 appears in an obituary in year 12. History is how normalization becomes visible. Never editorialize; let juxtaposition do the work.
