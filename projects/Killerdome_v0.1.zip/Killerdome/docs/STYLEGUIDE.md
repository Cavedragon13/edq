# STYLEGUIDE.md — Killerdome, Inc.

The tone rules from README (Design Rules #3, #4) made operational. Every string in the game is subject to this document.

## The One Test

> Would an actual corporate communications professional write this?

If no, rewrite it. No exceptions for menus, tooltips, buttons, error messages, or save-file names.

## Visual Language

- The UI is enterprise software: clean, professional, calm. Think dashboards, not arenas.
- Palette: corporate neutrals with one confident accent color. **Never** blood red as a theme color. Alert states use standard amber/red *semantics* only, sized like any SaaS product's.
- No skulls, flames, grunge textures, metal fonts, or "edgy" iconography — ever. Charts are charts.
- Typography: one workhorse sans (system stack is fine), generous whitespace, tabular numerals for money.

## Voice by Department

- **Legal:** precise, passive, liability-shaped. "The organization disputes the characterization."
- **PR / Strategic Communications:** warm, forward-looking, content-free. "Our thoughts are with the family. Safety remains our highest priority."
- **Finance:** neutral, numerical. "Q3 attrition-related expenses exceeded forecast."
- **Broadcast:** enthusiastic but network-safe.
- **Ernie (Tier 1):** friendly, brief, unsettling only in context. "Saw the gate numbers Saturday. Nice. We'll come by Thursday."

## The Euphemism Ladder

The same underlying event is named differently by era. This ladder is the satire's spine; the news feed makes it visible when old clippings sit beside new ones.

| Event | Era 1 (Roadside) | Era 2 (Regional) | Era 3 (National) | Era 4 (Institutional) |
|---|---|---|---|---|
| Fighter death | "a fatality" | "a ring fatality" | "a talent attrition event" | "a roster adjustment" |
| Serious injury | "got hurt bad" | "a serious injury" | "a career-impacting incident" | "an availability change" |
| The fights | "the fights" | "combat events" | "combat entertainment" | "the sport" |
| Loan shark | "Ernie" | "private lending" | "alternative liquidity partner" | — (retired) |
| Bribe | "a favor" | "a contribution" | "government relations" | "stakeholder alignment" |
| Union busting | "handling it" | "labor strategy" | "workforce flexibility initiative" | "modern engagement model" |

Rules:
- Characters use the ladder appropriate to their era and department **sincerely**. Nobody smirks.
- The player's own menu labels climb the ladder too. In Era 1 the button says "Pay Ernie." By Era 3 it says "Service Alternative Liquidity Obligations."
- Never annotate the shift. No tooltip says "notice how the language changed." Juxtaposition in the news history does all the work.

## Forbidden

- Ironic achievement names, fourth-wall breaks, direct moral commentary, "dark mode" as theming joke, references to real people or real scandals, gore of any kind (violence is always off-screen and post-hoc, arriving as paperwork).
