# CHARACTERS.md — Killerdome, Inc.

Recurring cast. All fictional composites; no real-person references (SATIRE.md). Characters age, retire, defect, and die on the calendar (Design Rule #5). Names generate from data pools; the archetypes below are fixed narrative roles.

## Capital
- **Ernie** — Community Lending Partner. Friendly, brief, punctual. Speaks only in Era-1 register even when the company has outgrown him. His retirement (via refinance) should feel oddly wistful. His collections crew is never shown, only inferred.
- **The Meridian Partner** — polished, data-forward, genuinely believes the directives help. "We're aligned on safety. We're also aligned on growth."
- **The Sovereign Representative** (Era 4) — impeccable, unfailingly courteous, owns 30% of everything.

## Opposition
- **The Senator** — builds a career on the company. Escalation ladder: statement → hearing → bill. Can be blunted by hiring their former chief of staff, who is excellent at their new job and slightly sad.
- **The Widow** — emerges from a fatality incident. Never a caricature; the game treats her with complete seriousness, which is exactly why PR's statements about her ring hollow.
- **The Documentarian** — patient, polite, always filming.

## Inside the Company
- **The Ringleader** — charismatic roster fighter who founds the Association. Three exits: quiet buyout, heel turn (with leak bomb), or across-the-table recognition. If martyred, a successor inherits a multiplier.
- **The Compliance Officer** (captive-insurer hire) — the closest thing to a conscience, expressed entirely in actuarial memos.
- **The First Employee** — hired week 1 to run parking; by Era 4, EVP of Guest Experience. The player's history in human form.
- **Defectors** — any senior hire may eventually leave to found a rival league (Rule #5), taking institutional knowledge with them.

## The Roster
Fighters carry: draw power, durability, age curve, temperament, hometown, and a generated two-line bio. Retired fighters can become coaches, commentators, defectors, ringleaders, or obituaries. The year-2 recruit / year-12 obituary pipeline is a deliberate design feature (SATIRE.md delivery #1).
