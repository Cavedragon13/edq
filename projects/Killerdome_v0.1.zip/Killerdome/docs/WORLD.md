# WORLD.md — Killerdome, Inc.

## Setting

A near-parallel present-day America, unnamed year. Everything is recognizable: cable TV, state athletic commissions, PACs, private equity, streaming rights. The single divergence is that this world's institutions proved willing to license what ours (so far) has not — one reasonable step at a time, starting in the Nevada desert.

## The Property

A failing mobile home park bordering an abandoned quarry outside a fictional Nevada town (working name: **Caliche Springs**). Back taxes owed. The quarry becomes the first venue; the mobile home park becomes, over the eras, fighter housing, then corporate campus, then a heritage site with a gift shop.

## Legality Map

- Era 1: nothing is sanctioned; the operation survives on remoteness, county indifference, and cash.
- Era 2: a handful of states sanction "combat events" under athletic commissions (fictional states first movers: whichever the simulation's lobbying makes cheapest). The map is a core strategic surface — venues, TV, and sponsors all key off it.
- Era 3: federal question. The Senator's bill vs. the industry's Standards Act.
- Era 4: international federations, Olympic exhibition question.

## Institutions (all fictional composites)

- **Networks:** regional sports channels → national broadcaster → streaming platforms, each with content standards that loosen as ratings rise.
- **Capital:** Ernie & Associates → Meridian Capital Solutions → unnamed sovereign funds.
- **Opposition:** the Senator's office, the Widow's foundation, a documentary production company, a rival league or two spawned by former employees (Design Rule #5).
- **The Commission:** state athletic regulators — adversaries in Era 2, colleagues by Era 4.

## Texture Notes

Concessions, parking, merchandising, and sponsor activations should always be visible in the fiction; the game's founding insight is that the crowd is worth more than the fight. Weather matters at the quarry. The world keeps moving: politicians retire, sponsors merge, fighters become coaches, employees defect and compete.
