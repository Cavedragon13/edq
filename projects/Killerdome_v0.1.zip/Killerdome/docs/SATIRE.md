# SATIRE.md — Killerdome, Inc.

What the satire targets, how it's delivered, and what it never does.

## Targets

- **Bureaucratic normalization**: how institutions make the unthinkable procedural.
- **Corporate language** as moral anesthesia (see STYLEGUIDE.md euphemism ladder).
- **Incremental compromise**: no single decision is monstrous; the accumulation is.
- **Regulatory capture**: the victory condition includes writing your own oversight law.
- **Oligarch excess**: the Exec Suite ladder and the Island — private luxury built from public spectacle.

## Non-Targets

- Individual cruelty. Nobody in this world is a sadist; everyone is doing their job well.
- Real people, real companies, real scandals. All institutions are fictional composites.
- The audience. Spectators are ordinary people at what their world tells them is ordinary entertainment.

## Delivery Mechanisms (in priority order)

1. **The news history.** Old clippings beside new ones. Year-2 recruit, year-12 obituary. No commentary.
2. **The euphemism ladder** climbing in the player's own UI.
3. **Ending documents** — liquidation report, memorial newsletter, press release, case study.
4. **The player's own optimization.** The strongest strategies should be the most quietly damning ones (the captive insurer, the heel turn, the contractor classification). The game rewards them exactly as a real market would.
5. **Directives from capital** — board seats and sovereign funds steering content in reasonable-sounding memos.

## The Prime Directive

Rule #3: **never wink.** If a joke requires the game to acknowledge it's joking, cut it. The player who never notices the satire should still have an excellent management game. The player who notices should get no confirmation.
