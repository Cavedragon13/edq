# UI.md — Killerdome, Inc.

The interface is the joke's straight man: enterprise software, executed sincerely. Visual rules in STYLEGUIDE.md govern everything here.

## Layout (single-page app)

- **Top bar:** company name/logo (evolves by era), date, treasury (tabular numerals), advance-week button.
- **Left nav:** department tabs — Operations, Talent, Finance, Regulatory Affairs, Communications, Executive. Tabs unlock by era; labels climb the euphemism ladder.
- **Main panel:** the active department's dashboard.
- **Right rail:** the four gauges (corporate display names, honest tooltips) and the news feed — persistent, scrollable to week 1, searchable. The news feed is the satire's primary surface and must never truncate history.

## Department Dashboards

- **Operations:** venue status, event scheduler (calendar grid), facilities/upgrades, weather.
- **Talent:** roster table (sortable), recruitment pool, contract/negotiation modal, Association panel when formed.
- **Finance:** P&L, lender relationships, loan console, expansion-window cards with countdowns, insurance (later: captive) panel.
- **Regulatory Affairs:** legality map (state grid), the Senator's bill tracker rendered as an ordinary Gantt chart, counter-tool retainers.
- **Communications:** incident-response queue, press-release composer (choose from sincere templates), documentary-access decision.
- **Executive:** the Suite ladder, OKR dashboard (Ending-6 milestones as ordinary corporate objectives), and eventually the Island builder (simple grid placement, RollerCoaster-Tycoon-compressed).

## Interaction Principles

- Every number the player sees must be explainable on hover (legibility target, GDD.md).
- Decisions are modals with 2–4 options written in department voice; consequences are never labeled morally.
- Keyboard navigable; contrast AA minimum; no animation longer than 200ms. It's business software.
- Incidents arrive as items in an **Incident Response** queue, not as alarms. The calm is the point.
