# GDD.md — Killerdome, Inc.

Version 0.1 (living document). This is the index; depth lives in the referenced docs.

## Summary

Single-player management simulation. The player transforms an accidental illegal desert attraction into America's largest combat entertainment corporation, one reasonable business decision at a time. The player never fights, never kills, and is never told the game is satire. See `README.md` for design philosophy and the five Design Rules — they are binding.

## Pillars

1. **Management first.** The sim must be fun with the satire removed. (README Project Goals.)
2. **The horror lives in the spreadsheet.** Complicity via optimization, never via chosen violence.
3. **Straight face, forever.** Enforced by STYLEGUIDE.md at the string level and ENDINGS.md at the structural level.
4. **History is the witness.** Persistent news feed, aging characters, and the euphemism ladder make normalization visible without commentary.

## Structure

- **Time & eras:** SYSTEMS.md §1 — weekly ticks, four eras from Roadside to Institutional.
- **Strategic layer:** SYSTEMS.md §2–3 — four coupled gauges (DEBT, HEAT, RISK, LABOR); every lever moves several.
- **Economy:** SYSTEMS.md §4–5, §8 — event revenue vs. fixed costs; three lender tiers from Ernie to sovereign capital; deliberate late-game money sinks keep leverage interesting.
- **People:** SYSTEMS.md §7 — roster, FM-style contract negotiation, the Association, the heel turn.
- **Pressure:** SYSTEMS.md §6, §9 — insurance/captive; a HEAT ecosystem of named opponents (the Senator, the Widow, the documentary crew).
- **Vanity:** SYSTEMS.md §10 — the Exec Suite ladder ending at the Island.
- **Outcomes:** ENDINGS.md — five failures and one victory, each delivered as a corporate document.

## Player Experience Targets

- First completion: 15–25 hours. Fail endings reachable much faster.
- The player should be able to articulate *why* any show sold or any gauge moved (legibility over realism).
- The intended emotional arc: amusement → competence → unease → recognition, without the game ever asking for it.

## Scope Boundaries

No combat gameplay. No multiplayer. No real people or real scandals. No gore — consequences arrive as paperwork. Content additions route through EVENTS.md and CHARACTERS.md and must pass STYLEGUIDE.md.
