# ROADMAP.md — Killerdome, Inc.

Executable implementation plan. One phase per session. Each phase ends: run checks (`npx tsc --noEmit`, `npx vitest run`, `npm run build`), update `docs/CHANGELOG.md`, **stop for review**. A phase is COMPLETE only when logged as such in CHANGELOG.md.

Stack and constraints: see `CLAUDE.md`. Balance numbers: `src/data/balance.ts`, all tunable, all placeholder until Phase 9.

---

## Phase 0 — Scaffold & Engine Skeleton
**Reads:** CLAUDE.md.
**Build:** Vite + TypeScript strict project; `src/engine/` (headless), `src/ui/`, `src/data/` separation; seeded PRNG module (`rng.ts`); game-state type + save/load to localStorage with `saveVersion` and migration stub; weekly tick loop that advances a date; Vitest wired with first tests (RNG determinism, save round-trip).
**Acceptance:** all checks pass; a headless test runs 520 ticks reproducibly from a seed; `npm run build` outputs a working static page showing the date advancing.

## Phase 1 — Core Loop: Venue, Events, Money
**Reads:** SYSTEMS.md §1, §4; UI.md.
**Build:** single venue (the quarry); event scheduling (pick week, set ticket price); attendance model v0.1; weekly fixed costs; treasury; a plain corporate dashboard UI (see STYLEGUIDE.md — enterprise software, no theatrics); news feed panel (persistent history).
**Acceptance:** player can schedule shows, watch cash rise/fall, and go broke; attendance responds legibly to price; news feed logs every event; engine tests cover the attendance and cost math.

## Phase 2 — Talent & Staff
**Reads:** SYSTEMS.md §7 (roster/stats only, no association yet); CHARACTERS.md.
**Build:** fighter roster with stats and age curves; recruitment pool; simple contracts (weekly pay, duration); card composition affecting draw; staff hires (medical, PR, legal, ops) as policy baselines.
**Acceptance:** card quality visibly drives attendance; contracts expire and renew; fighters age; tests cover stat curves and payroll.

## Phase 3 — The Four Gauges & Coupling
**Reads:** SYSTEMS.md §2, §3.
**Build:** DEBT/HEAT/RISK/LABOR gauges with corporate display names + honest tooltips; typed `GaugeDelta` system supporting immediate, scheduled (delayed bomb), and conditional deltas; incidents (RNG weighted by RISK and card format) feeding gauges and news; gauge drift toward policy baselines; sustained-extreme fail-state detectors (detection only — endings arrive Phase 7).
**Acceptance:** the coupling matrix in SYSTEMS.md §3 is implemented as data and covered by tests; an unsafe-format show measurably moves three gauges; delayed deltas fire on schedule.

## Phase 4 — Capital: Lenders & Collections
**Reads:** SYSTEMS.md §5, §8 (expansion windows: distressed acquisition only).
**Build:** Tier-1 lender (Ernie, UI label "Community Lending Partner") with vig and collections events on missed payments; Tier-2 (Meridian) with covenants and one board-directive event; refinancing; first expansion window (distressed league acquisition with a countdown).
**Acceptance:** a player can survive early game only via Tier-1 debt and escape it via refinancing; missed Ernie payments produce collections incidents; covenant breach produces consequences; tests cover interest math and covenant checks.

## Phase 5 — Labor: Negotiation, Association, Heel Turn
**Reads:** SYSTEMS.md §7 complete; EVENTS.md labor pool.
**Build:** contract negotiation minigame (offer/counteroffer over pay, benefits, image rights, contractor classification); association formation on LABOR threshold + ringleader; three resolutions (quiet buyout / heel turn with scheduled leak bomb / recognition); strike detector.
**Acceptance:** negotiation is playable and affects LABOR; heel turn drops LABOR immediately and the leak bomb, when it fires in tests, applies the martyrdom multiplier; recognition permanently reduces LABOR volatility.

## Phase 6 — Insurance & Politics
**Reads:** SYSTEMS.md §6, §9; EVENTS.md politics pool.
**Build:** premium = f(RISK); carrier non-renewal chain; zero-carrier lockout; captive subsidiary unlock (Era 3) with self-funded payouts; HEAT ecosystem actors (Senator escalation ladder, Widow, documentary crew) as data-driven event chains; counter-tools (lobbying retainer, PAC, foundation, safety study, chief-of-staff hire); state legality map.
**Acceptance:** ignoring RISK leads to carrier death spiral; captive converts premiums into wagers (tests verify treasury flows); Senator escalates through statements → hearing → bill; lobbying measurably slows the bill clock.

## Phase 7 — Eras & Endings
**Reads:** SYSTEMS.md §1; ENDINGS.md; STYLEGUIDE.md euphemism ladder.
**Build:** era transitions with milestone triggers; euphemism ladder applied to news strings by era; all six endings as generated documents assembled from run history; Ending-6 milestone OKR dashboard; hostile-takeover exposure if public.
**Acceptance:** each ending reachable in a scripted test run; ending documents contain real names/dates/figures from the run; era transitions re-skin terminology without breaking saves.

## Phase 8 — Exec Suite & The Island
**Reads:** SYSTEMS.md §10; ENDINGS.md §6.
**Build:** exec-suite ladder rungs 1–5 (vanity sinks with small prestige effects); island purchase and compressed builder minigame (grid placement: helipad, marina, wellness pavilion, conference center, private arena); private-arena exhibition events; island completion feeding Ending 6.
**Acceptance:** ladder purchases compete measurably with business needs; island builder is playable start-to-finish; private arena events run with era-4 language.

## Phase 9 — Balance, Content Fill & Polish
**Reads:** all docs.
**Build:** full events pools from EVENTS.md; character roster from CHARACTERS.md; balance pass targeting a 15–25 hour first completion; onboarding (a straight-faced "New Franchisee Orientation" tutorial); accessibility pass (keyboard nav, contrast); save migrations verified across all prior phases.
**Acceptance:** a full playthrough to Ending 6 is possible and fun; a deliberate-failure playthrough reaches each fail ending; no tone-rule violations in a full string audit (CLAUDE.md Tone Rules).
