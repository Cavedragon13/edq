# EVENTS.md — Killerdome, Inc.

Random-event pools, era-gated, data-driven (`src/data/events/`). Every event: trigger conditions, weighted options, `GaugeDelta[]` (immediate/scheduled/conditional), and news-feed strings per era (STYLEGUIDE.md ladder). This v0.1 list seeds each pool; Phase 9 fills them out.

## Operations
- Porta-john vendor doubles prices the week of the big show (Era 1).
- Parking overflow onto federal land; a ranger writes a citation (Era 1).
- Jumbotron financing offer — impressive, debt-hungry (Era 2).
- Concessionaire proposes exclusive pouring rights; sponsor conflict (Era 2–3).
- Weather: dust storm / flash flood at the quarry (Era 1–2).

## Talent
- A headliner demands a private trailer; the roster notices the answer either way.
- Two fighters' rivalry turns real backstage — hype opportunity, RISK bump.
- A retired fighter asks for a coaching job (Rule #5 continuity; small LABOR ▼).
- A prospect's medical screening shows a concerning result; booking him anyway is quiet, profitable, and a delayed bomb.

## Finance
- Ernie "comes by Thursday" (missed-payment collections chain, Era 1).
- Meridian directive: "audiences respond to higher-stakes formats" (Era 2–3).
- Auditor flags concession cash handling; fixing it costs, ignoring it compounds.
- Sovereign partner requests a topic never be mentioned on broadcast (Era 4).

## Politics & Press
- The Senator's floor statement names the company (HEAT chain start).
- The Widow's foundation buys billboards on the interstate.
- Documentary crew requests access — grant/deny, both with delayed content bombs.
- A leaked internal memo (conditional bomb from heel turn / buyouts / medical booking).
- A jobs-created ribbon cutting invitation from a friendly mayor (HEAT ▼, photo op).

## Labor
- Association organizing meeting reported by a loyal staffer — act on it or don't (acting on it works and raises long-term LABOR volatility).
- Death-benefit claim dispute goes public.
- A ringleader emerges (charisma-weighted roster pick) — enables SYSTEMS.md §7 resolutions.
- Strike vote scheduled the week before the flagship PPV.

## Milestones (scripted, once each)
- First TV camera crew shows up uninvited (Era 1 → 2 signal).
- First national sponsor sniff test — they ask what happens "if something happens."
- Cereal-box licensing call (Ending 6 milestone).
- A sitting president's advance team makes discreet inquiries (Ending 6 milestone).
