# Directory reserved for game assets. Nothing here until Phase 1.
