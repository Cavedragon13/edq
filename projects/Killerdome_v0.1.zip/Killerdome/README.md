# READ ME

> **A satirical management simulation about building the world's most successful combat entertainment corporation.**

---

## High Concept

*Killerdome, Inc.* is a single-player management simulation in which the player transforms an accidental illegal desert attraction into America's largest combat entertainment company.

The player never participates in combat.

Instead, they manage the business behind it.

Every expansion, promotion, sponsorship, legal decision, and public relations campaign grows the company while slowly normalizing something that would once have been considered unthinkable.

The satire comes from bureaucracy—not blood.

---

# Design Philosophy

Killerdome is **not** a combat game.

It is **not** a shooter.

It is **not** a fighting game.

It is a management simulation.

The player manages:

- finances
- facilities
- talent
- sponsors
- media
- public relations
- legal compliance
- government relations
- logistics
- growth

Combat exists primarily as a business product.

The player worries about television contracts, insurance costs, concession revenue, staffing shortages, sponsor demands, parking capacity, and political pressure.

---

# Tone

The game is presented completely straight.

No one in the world believes they're participating in something dystopian.

The interface is clean.

Corporate.

Professional.

Executives speak in executive language.

Lawyers speak in legal language.

Marketing speaks in marketing language.

Everything sounds reasonable.

The player slowly realizes that perfectly ordinary business decisions have built something monstrous.

---

# Inspirations

Management

- RollerCoaster Tycoon
- Two Point Hospital
- Tropico
- Game Dev Story
- Papers, Please

Satire

- RoboCop
- The Running Man
- Idiocracy
- Starship Troopers

---

# Player Fantasy

The player is not a fighter.

The player is not a dictator.

The player is a CEO.

Every problem is solved with:

- budgets
- staffing
- marketing
- scheduling
- construction
- public relations
- lobbying
- compromise

---

# The Beginning

The player inherits a failing mobile home park bordering an abandoned quarry somewhere in the Nevada desert.

The property owes back taxes.

One afternoon, two strangers begin fighting after an argument involving shopping carts.

People gather.

Someone begins charging for parking.

Someone else sells drinks.

By the following weekend hundreds of spectators arrive.

The player realizes the crowd is more valuable than the fight.

A business is born.

---

# Core Gameplay Loop

1. Schedule an event.
2. Recruit talent.
3. Upgrade facilities.
4. Hire staff.
5. Balance the budget.
6. Respond to random events.
7. Expand the business.
8. Repeat.

---

# Core Themes

Institutional growth.

Corporate bureaucracy.

Public relations.

Commercialization.

Political influence.

Media spectacle.

Mission creep.

Normalization.

Incremental compromise.

---

# What Makes Killerdome Different?

The game is never about asking:

> "How do we make the fights more violent?"

Instead it asks:

> "How do we manage success?"

Every mechanic grows naturally from that question.

---

# Design Rules

## Rule #1

The player never directly kills anyone.

---

## Rule #2

Every decision should feel reasonable.

Bad outcomes should emerge from the accumulation of reasonable business decisions.

---

## Rule #3

Never wink at the audience.

The game never admits it is satire.

Players discover the satire themselves.

---

## Rule #4

Corporate language is part of the joke.

Examples:

Government Relations

Stakeholder Outreach

Talent Acquisition

Incident Response

Regulatory Affairs

Community Partnership

Strategic Communications

---

## Rule #5

The world keeps moving.

Characters age.

Politicians retire.

Sponsors merge.

Fighters become coaches.

Employees become competitors.

The player's history remains visible.

---

# Project Goals

Build a management simulation first.

Build satire second.

Never sacrifice gameplay for the joke.

If the management isn't fun, the satire won't matter.

---

# Repository Layout

```
Killerdome/
│
├── README.md
│
├── docs/
│   ├── GDD.md
│   ├── ROADMAP.md
│   ├── SYSTEMS.md
│   ├── SATIRE.md
│   ├── WORLD.md
│   ├── EVENTS.md
│   ├── CHARACTERS.md
│   ├── UI.md
│   ├── STYLEGUIDE.md
│   └── CHANGELOG.md
│
├── assets/
│
├── src/
│
├── saves/
│
└── tools/
```

---

# Current Status

Pre-production.

The project is currently focused on documenting systems before implementation.

No engine has been selected.

No programming language has been selected.

The documentation defines the project independently of implementation.

---

# Versioning

Major revisions to the design documents should increment the document version.

The documentation is intended to evolve alongside development.

The GDD is considered a living document.

---

## Motto

> "Every empire begins with somebody charging for parking."